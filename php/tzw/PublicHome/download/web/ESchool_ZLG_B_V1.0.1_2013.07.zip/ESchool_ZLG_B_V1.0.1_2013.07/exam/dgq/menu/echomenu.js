// JavaScript Document

function StartList()
{
	if( document.all && document.getElementById )
	{
		navRoot = document.getElementById("nav");
		for( i = 0; i < navRoot.childNodes.length; i++ )
		{
			node = navRoot.childNodes[i];
			if( node.nodeName == "LI" )
			{
				node.onmouseover = function()
				{
					this.className += " over";
				}
				
				node.onmouseout = function()
				{
					this.className = this.className.replace(" over", "");	
				}
			}
		}
	}
}

function CreateMenu()
{
	var ele_ul = document.createElement("ul");
	ele_ul.setAttribute("id", "nav");
	
	for( i = 0; i < menu.length; i++ )
	{
		var ele_li = document.createElement("li");
		var ele_a = document.createElement("a");
		ele_a.setAttribute("href", "");
		var ele_text = document.createTextNode( menu[i][0] );
		ele_a.appendChild(ele_text);
		ele_li.appendChild(ele_a);
		var ele_ul_temp = document.createElement("ul");
		
		for( j = 0; j < menu[i].length-1; j++ )
		{
			var ele_li_temp = document.createElement("li");
			var ele_text_temp = document.createTextNode( menu[i][j+1] );
			var ele_a_temp = document.createElement("a");
			ele_a.setAttribute("href", "");
			ele_a.appendChild(ele_text_temp);
			ele_li_temp.appendChild(ele_a);
			ele_ul_temp.appendChild(ele_li_temp);
		}
		ele_li.appendChild(ele_ul_temp);
		ele_ul.appendChild(ele_li);
	}

	var ele_body = document.getElementById("body1");
	ele_body.appendChild(ele_ul);
		
	StartList();
}

var menu = new Array();
function GetXML()
{
	var xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
	xmlDoc.async="false";
	xmlDoc.load("menu.xml");
	var nodes = xmlDoc.documentElement.childNodes;
	
	for( i = 0; i < nodes.length; i++ )
	{
		var len = nodes(i).childNodes.length + 1;
		menu[i] = new Array(len);
		menu[i][0] = nodes(i).getAttribute("type");
		for( j = 0; j < nodes(i).childNodes.length; j++ )
		{
			menu[i][j+1] = nodes(i).childNodes(j).text;	
		}
	}
	CreateMenu();
}