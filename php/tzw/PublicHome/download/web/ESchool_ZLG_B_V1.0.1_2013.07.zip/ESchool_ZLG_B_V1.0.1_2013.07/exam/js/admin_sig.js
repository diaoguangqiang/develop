function sigformcheck()
{
	var msg = "";
	if ( !document.sigform("sig_title").value )
	{
		msg = "��Ŀ����Ϊ��\r";
	}
	
	if ( !document.sigform("sig_a").value )
	{
		msg += "ѡ��A����Ϊ��\r";
	}
	
	if ( !document.sigform("sig_b").value )
	{
		msg += "ѡ��B����Ϊ��\r";
	}
	
	if ( !document.sigform("sig_c").value )
	{
		msg += "ѡ��C����Ϊ��\r";
	}
/*	
	if ( !document.sigform("sig_d").value )
	{
		msg += "ѡ��D����Ϊ��\r";
	}

	var checked = false;
	var sigradio = document.getElementByName("sig_answer");
	window.alert(sigradio.length);
	
	for( var i = 0; i < sigradio.length; i++ )
	{
		checked = checked || sigradio[i].checked;
	}
	
	if ( !checked )
	{
		msg += "�𰸲���Ϊ��\r";
	}
	
*/
	if ( msg )
	{
		window.alert(msg);
		return false;
	}
	else
	{
		return true;
	}
}

/*function tbsigup()
{
	alerfunt(document.all("sig_answer").value);
	var sum=0;
	var number=sigup.arguments.length;//ʹ�ú����Ĳ�������
	
	for(var i=0;i<number;i++)
	{
		sum+=sigup.arguments[i];
	}
	
	var test = eval("x = 8 + 9 + 5 / 2")
	document.write( test);
	document.write("<br>"+escape("hello there"));
	alert("test");
	document.write("<br>"+unescape(escape(" hello there")));
	alert("dddd");
	
	//document.write("ddd");
	//window.location = "admin_sig.asp?action=sigup";
	//return sum;
	return false;
}

function tbsigdown()
{
	return false;
}

function tbsigdown()
{
	return false;
}

function tbsigdel()
{
	return false;
}

function tbsigchange()
{
	return false;
}

function tbsigadd()
{
	return false;
}


function imgover()
{   
	document.sigimg.src = "../image/1.jpg";	
}

function imgout(img)
{
	document.sigimg.src = "../image/2.jpg";	
}
*/