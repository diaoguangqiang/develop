function subformcheck()
{
	var msg = "";
	alert(document.sigform("sub_problem").value);
	if ( !document.sigform("sub_problem").value )
	{
		msg = "���ⲻ��Ϊ��\r";
	}
	
	if ( !document.sigform("sig_answer").value )
	{
		msg += "�𰸲���Ϊ��\r";
	}
	
	
/*	
	if ( !document.sigform("sig_d").value )
	{
		msg += "ѡ��D����Ϊ��\r";
	}

	var checked = false;
	var sigradio = document.getElementByName("sig_answer");
	window.alert(sigradio.length);
	
	for( var i = 0; i < sigradio.length; i++ )
	{
		checked = checked || sigradio[i].checked;
	}
	
	if ( !checked )
	{
		msg += "�𰸲���Ϊ��\r";
	}
	
*/
	if ( msg )
	{
		window.alert(msg);
		return false;
	}
	else
	{
		return true;
	}
}