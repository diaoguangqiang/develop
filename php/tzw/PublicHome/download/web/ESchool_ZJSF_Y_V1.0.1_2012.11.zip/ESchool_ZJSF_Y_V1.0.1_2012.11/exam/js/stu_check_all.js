function checkall(flag)
{		
	var input = document.getElementsByTagName("input");

    for (var i=0;i<input.length ;i++ )
    {
        if(input[i].type=="checkbox")
		{
		    input[i].checked = flag;
		}
    }
}