function addcheck()
{
	var flag = 0;
	var allRadio = document.forms[0].elements["selno"];
	
	var selnovalue = 0;
	var sno = 0;
	var snof = 0;
	var snol = 0;
	
	sno = document.form1("sno").value;
	snof = document.form1("snof").value;
	snol = document.form1("snol").value;
	
	if( allRadio[0].checked )
	{
		if( !sno )
		{
			alert("�����뵥��¼����!");
			return false;
		}
		else
		{
			return true;
		}
	}

	if( allRadio[1].checked )
	{
		if( snof  )
		{
			if( !snol )
			{
				alert("�������յ�ѧ��");
				return false;				
			}
			else
			{
				return true;
			}
		}
		else
		{
			alert("���������ѧ��");
			return false;
		}
	}
}
