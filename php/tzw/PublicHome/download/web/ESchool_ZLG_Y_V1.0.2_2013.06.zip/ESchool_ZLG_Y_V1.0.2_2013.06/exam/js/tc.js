function tc()
{
	alert("d");	
}